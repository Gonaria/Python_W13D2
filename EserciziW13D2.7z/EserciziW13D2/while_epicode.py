nome_scuola = "Epicode" 
x = 0 
while x < len(nome_scuola): 
    print(nome_scuola[x]) 
    x += 1
# Stampare ogni carattere della stringa, uno su ogni riga, utilizzando un costrutto while.1