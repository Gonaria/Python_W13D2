#Calcolare e stampare tutte le prime 10 potenze di 2 utilizzando un ciclo. Utilizzeremo: • un ciclo per generare i primi 10 numeri,
potenze_due = []

for i in range(1, 11):
    potenza = 2 ** i
    potenze_due.append(potenza)

print("Le prime 10 potenze di 2 sono:")
for potenza in potenze_due:
    print(potenza)