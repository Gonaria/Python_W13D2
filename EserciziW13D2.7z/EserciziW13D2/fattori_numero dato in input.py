#Memorizza e stampa tutti i fattori di un numero dato in input. Esempio: • input: 150 • output: [2, 3, 5, 5]
def fattori_numero(numero):
    fattori = []
    i = 2
    while i <= numero:
        if numero % i == 0:
            fattori.append(i)
            numero = numero / i
        else:
            i += 1
    return fattori

numero = int(input("Inserisci un numero: "))
print(fattori_numero(numero))