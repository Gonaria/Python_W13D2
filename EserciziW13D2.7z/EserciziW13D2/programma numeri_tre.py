#Scrivere un programma che, data una lista di numeri, fornisca in output i tre numeri più grandi; 
#gestire il caso in cui la lista sia più corta di tre, 
#e quando uno o più dei numeri selezionati sono uguali.
def tre_numeri_piu_grandi(lista):
    if len(lista) < 3:
        return "La lista non contiene almeno tre numeri"
    numeri_ordinati = sorted(set(lista), reverse=True)
    return numeri_ordinati[:3]

lista_numeri = [10, 5, 7, 7, 3, 8, 10, 12]
risultato = tre_numeri_piu_grandi(lista_numeri)
#print(f"I tre numeri più grandi nella lista sono: {risultato}")


numeri = [10, 5, 7, 7, 3, 8, 10, 12]

numeri_uguali = []

for numero in numeri:
    if numeri.count(numero) > 1 and numero not in numeri_uguali:
        numeri_uguali.append(numero)

print(numeri_uguali)