n = int(input("Inserisci un numero N: ")) 
x = 0 
potenza = 1
while x < n: 
    print(2**potenza) 
    x += 1 
    potenza += 1
# Calcolare e stampare tutte le prime N potenze di 2 utilizzando un ciclo while, domandando all'utente di inserire N 4 