#Abbiamo una lista di stringhe di prezzi in dollari, che erroneamente sono stati scritti con il simbolo dell'euro: prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"] cambiare il simbolo dell'euro (€) in quello del dollaro ($)
# per ogni stringa nella lista; il risultato sarà memorizzato in un'altra lista.
prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]
prezzi_dollari=[]
for prezzo in prezzi:
    prezzo_dollaro = prezzo.replace("€", "$")
    prezzi_dollari.append(prezzo_dollaro)

print(prezzi_dollari)
