#Osservando la sintassi dei dizionari, possiamo notare qualche affinità con il formato JSON?
# Entrambi utilizzano le parentesi graffe per indicare la inizio e la fine dell'oggetto