studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]
def aggiungi_corso(studente, corsi):
    index = studenti.index(studente) 
if len(corsi) > index: 
    if corsi[index] != aggiungi_corso:
        corsi[index] = aggiungi_corso
else: 
    corsi.append(aggiungi_corso)
    aggiungi_corso("Emma", "Data Analyst") 
    aggiungi_corso("Faith", "Backend") 
    aggiungi_corso("Grace", "Frontend") 
    aggiungi_corso("Henry", "Cybersecurity")
if len(studenti) == len(corsi):
    print(f"La lista degli studenti è:"[corsi]) 
else: 
    print("Le liste non sono della stessa lunghezza")

