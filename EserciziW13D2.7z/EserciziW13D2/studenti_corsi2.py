def aggiungi_corsi(studenti, corsi):
   for studente in studenti: 
     if studente == "Emma" and "Data Analyst" not in corsi: 
      corsi.append("Data Analyst")
      if studente == "Faith" and "Backend" not in corsi: 
       corsi.append("Backend") 
     elif studente == "Grace" and "Frontend" not in corsi: 
        corsi.append("Frontend") 
     elif studente == "Henry" and "Cybersecurity" not in corsi: 
       corsi.append("Cybersecurity")
     if len(studenti) == len(corsi):
        print(corsi)
studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]
aggiungi_corsi(studenti, corsi)          
if len(studenti) == len(corsi):
        print(corsi)