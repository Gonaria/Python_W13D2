#Scrivere un programma che • in input acquisisce una lista di numeri e un numero K • in output, dovrà restituire la media di tutti i numeri nella lista maggiori o uguali a K •
# se non ce ne dovesse essere nessuno, dovrà stampare a schermo un messaggio adeguato.
def calcola_media(lista, K):
    numeri_maggiore_uguale_K = [numero for numero in lista if numero >= K]

    if not numeri_maggiore_uguale_K:
        print("Nessun numero maggiore o uguale a K nella lista")
    else:
        media = sum(numeri_maggiore_uguale_K) / len(numeri_maggiore_uguale_K)
        print(f"La media dei numeri maggiori o uguali a {K} nella lista è {media}")

numeri = input("Inserisci una lista di numeri separati da spazi: ").split()
numeri = [int(numero) for numero in numeri]
# Acquisizione della lista di numeri
numeri = input("Inserisci una lista di numeri separati da spazi: ").split()
numeri = [int(numero) for numero in numeri]
# Acquisizione del numero K
K = int(input("Inserisci il numero K: "))
# Calcolo della media dei numeri maggiori o uguali a K nella lista
calcola_media(numeri, K)
