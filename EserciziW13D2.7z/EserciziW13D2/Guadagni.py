#Abbiamo una lista con i guadagni degli ultimi 12 mesi (supponiamo da Gennaio a Dicembre): guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50] dobbiamo confrontare, stampando tutto a video, il guadagno di ogni mese con la media dei guadagni precedenti, e specificare nell'output se il guadagno attuale è maggiore o minore della media dei precedenti. 
#Esempio di un possibile output: Mese 1: 100 € Mese 2: 90 € (media prec: 100 € - il guadagno attuale è minore),-
#Mese 3: 70 € (media prec: 95 € - il guadagno attuale è minore)

guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50]
for i in range(1, len(guadagni)):
    media_precedente = sum(guadagni[:i]) / i
    confronto = "maggiore" if guadagni[i] > media_precedente else "minore"
    print(f"Mese {i+1}: {guadagni[i]} € (media prec: {media_precedente:.2f} € - il guadagno attuale è {confronto})")