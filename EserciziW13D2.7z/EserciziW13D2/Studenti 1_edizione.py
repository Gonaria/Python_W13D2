#Abbiamo tre liste della stessa lunghezza, dove ogni elemento nella medesima posizione si riferisce ai dati dello stesso studente: studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend", "Frontend", "Cybersecurity"] edizioni = [1, 2, 3, 2, 2, 1, 3, 3] • 
#Stampare a video tutti e soli gli studenti che frequentano una prima edizione; non tutti i dati potrebbero essere necessari
#Riuscite a vedere una similarità con la logica che si usa in SQL e le tabelle relazionali? Si potrei interpretare il numero dell'edizione come PK e utilizzarla per movimentare i dati
studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"]
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend", "Frontend", "Cybersecurity"]
edizioni = [1, 2, 3, 2, 2, 1, 3, 3]                           
studenti_prima_edizione = [studenti[i] for i in range(len(studenti)) if edizioni[i] == 1] 
for studente in studenti_prima_edizione: 
  print(f"Gli studenti della 1 edizione sono:", studente)                      