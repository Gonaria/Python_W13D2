#Scrivere un programma che, data una lista di numeri, fornisca in output il minimo e il massimo 
#(possiamo usare o meno le funzioni built-in min() e max()).
def trova_minimo_massimo(lista):
    minimo = None
    massimo = None
    
    for numero in lista:
        if minimo is None or numero < minimo:
            minimo = numero
        if massimo is None or numero > massimo:
            massimo = numero
    
    return minimo, massimo

numeri = [5, 10, 2, 8, 15]
minimo, massimo = trova_minimo_massimo(numeri)

print("Il minimo è:", minimo)
print("Il massimo è:", massimo)