#Calcolare (ma non stampare) le prime N potenze di K; ognuna di esse andrà memorizzata in coda a una lista. 
#Alla fine, stampare la lista risultante. Proviamo con diversi valori di K, 
#oppure facciamola inserire all'utente.Realizzare con un ciclo for
def potenze_prime(K, N, potenze=[]):
    if N == 0:
        return potenze
    return potenze_prime(K, N-1, potenze + [K**N])

K = int(input("Inserisci il valore di K: "))
N = int(input("Inserisci il numero di potenze da calcolare: "))
lista_potenze = potenze_prime(K, N)
print(lista_potenze)