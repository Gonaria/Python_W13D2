#Abbiamo la stringa: nome_scuola = "Epicode" Stampare ogni carattere della stringa, uno su ogni riga, utilizzando un costrutto for.
nome_scuola = "Epicode"
for carattere in nome_scuola: 
    print(f"stampa una lettera in ogni riga:",carattere)
