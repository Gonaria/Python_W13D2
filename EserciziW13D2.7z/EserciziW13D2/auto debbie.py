#Creiamo un dizionario che assegni ad ogni proprietario la sua auto, sapendo che: • 
#Ada guida una Punto • Ben guida una Multipla • Charlie guida una Golf • Debbie guida una 107 
#tampiamo il dizionario per intero, e poi l'auto associata a Debbie.
dizionario_proprietari_auto = { 'Ada': 'Punto', 'Ben': 'Multipla', 'Charlie': 'Golf', 'Debbie': '107' }
print(dizionario_proprietari_auto)
print("L'auto associata a Debbie è: ", dizionario_proprietari_auto['Debbie'])
