#Calcolare (ma non stampare) le prime N potenze di K; ognuna di esse andrà memorizzata in coda a una lista. 
#Alla fine, stampare la lista risultante. Proviamo con diversi valori di K, oppure facciamola inserire all'utente. 
#con un ciclo while
N = int(input("Inserisci il numero di potenze da calcolare: "))
K = int(input("Inserisci la base delle potenze: "))

potenze = []
i = 1

while i <= N:
    potenza = K ** i
    potenze.append(potenza)
    i += 1

print("Lista delle prime", N, "potenze di", K, ":", potenze)
