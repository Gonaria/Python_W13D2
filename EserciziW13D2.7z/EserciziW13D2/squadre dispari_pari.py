#Abbiamo una lista di studenti: studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry", "Isabelle", "John"] vogliamo dividere gli studenti in due squadre per un campionato di Uno nel seguente modo: selezioneremo i nomi in posizione pari per un squadra, e i nomi in posizione dispari per l'altra. 
#Creiamo due liste per ogni squadra, e alla fine visualizziamole.
studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry", "Isabelle", "John"]
team_pari = []
team_dispari = []
for i in range(len(studenti)): 
    if i % 2 == 0:
        team_pari.append(studenti[i]) 
else: team_dispari.append(studenti[i])
print("Squadra pari:", team_pari)
print("Squadra dispari:", team_dispari)




