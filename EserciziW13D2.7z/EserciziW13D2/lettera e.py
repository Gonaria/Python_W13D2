#Abbiamo una lista di parole: parole = ["Albergo", "Sedia", "Borgo", "Petalo", "Eremo", "Belvedere", "Semestre", "Esteta", "Sosta", "Orpello", "Abete", "Orologio", "Cesta", "Ermellino"] 
#stampiamo, per ogni parola, quante volte appare la lettera "e"; 
#facciamo attenzione al fatto che appare sia maiuscola che minuscola.
parole = ["Albergo", "Sedia", "Borgo", "Petalo", "Eremo", "Belvedere", "Semestre", "Esteta", "Sosta", "Orpello", "Abete", "Orologio", "Cesta", "Ermellino"]
for parola in parole:
    count = parola.lower().count("e")  
    print(f"Nella parola '{parola}' la lettera 'e' appare {count} volte.")    