#Abbiamo una lista di codici fiscali: lista_cf = ["ABCDEF95G01A123B", "GHIJKL91M02A321C", "MNOPQR89S03A456D", "STUVWX95Z04A654E", "XYZABC01D05A789F", "DEFGHI95J06A987G"] • trovare i codici fiscali che contengono "95", metterli in una lista, e alla fine stamparla; • 
#inoltre, per ognuno di essi, stampare a video i caratteri relativi al nome e cognome
lista_cf = ["ABCDEF95G01A123B", "GHIJKL91M02A321C", "MNOPQR89S03A456D", "STUVWX95Z04A654E", "XYZABC01D05A789F", "DEFGHI95J06A987G"]
codici_fiscali_95 = []
for cf in lista_cf: 
    if "95" in cf: 
        codici_fiscali_95.append(cf)
for cf in codici_fiscali_95: 
    nome = cf[0:2] 
    cognome = cf[3:5]
    print(f"Nome: {nome}, Cognome: {cognome}")
    print(codici_fiscali_95)