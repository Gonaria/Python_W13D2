#Abbiamo due dizionari che assegnano ad ogni proprietario la propria auto: 
#dizionario_auto = {"Ada": "Punto", "Ben": "Multipla", "Charlie": "Golf", "Debbie": "107", "Emily": "A1"} 
#nuovi_proprietari = {"Ben": "Polo", "Fred": "Octavia", "Grace": "Yaris", "Hugh": "Clio"} 
#Aggiornare il dizionario dizionario_auto con i dati contenuti in nuovi_proprietari e stamparlo.
# Cosa è successo a Ben? ha cambiato la sua auto da Multipla a Polo, perchè fa parte della lista dei nuovi proprietari con un auto diversa
dizionario_auto = {"Ada": "Punto", "Ben": "Multipla", "Charlie": "Golf", "Debbie": "107", "Emily": "A1"}
nuovi_proprietari = {"Ben": "Polo", "Fred": "Octavia", "Grace": "Yaris", "Hugh": "Clio"}
for proprietario, auto in nuovi_proprietari.items():
   dizionario_auto[proprietario] = auto
print(dizionario_auto) 