#Scrivere un programma che, data una lista di numeri, come output stamperà lo stesso numero di asterischi su righe diverse, ottenendo una semplice visualizzazione grafica 
#Esempio, supponendo di avere il seguente input: numeri = [5, 2, 3, 4] L'output sarà: ***** ** *** ****
numeri = [5, 2, 3, 4]
for num in numeri: 
    print('*' * num)

